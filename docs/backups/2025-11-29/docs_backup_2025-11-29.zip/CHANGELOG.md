## 2025-11-29 Phase 1 — Initial validation layer

- Added shared validation types `src/shared/validation.types.ts` (ValidationSeverity, ValidationIssue, ValidationResult).
- Added refrigeration validation helper `src/modules/refrigeration/refrigeration.validation.ts`.
- Wired refrigeration module to perform validation before running engine; engine run is blocked on validation errors.
- Documentation: updated `docs/process/DiagX_master_seed_V3.md` with Phase 1 validation notes.

## 2025-11-29 Phase 2 — Engine normalization and airside validation

- Inventory: added `docs/inventory/DiagX_Engines_Inventory.md` (canonical list of engine entry points for Phase 2).
- Normalized engine result types to use `EngineResult<V,F>` for engines: airside, refrigeration, compressor (recip & scroll), reversing valve.
- Exported and standardized engine recommendation helpers (generateXxxRecommendations) for testing and lock-in of behavior.
- Implemented conservative airside validation `src/modules/airside/airside.validation.ts` and wired into `airside.module` to block engine runs when fatal validation errors exist.
- Added recommendation helper tests and airside validation tests to lock current behavior in place.

## Unreleased
- Added `docs/Testing limits.md` (created by request).
- Documented multiple Vitest runs, configuration changes, and full scenario matrix in `docs/Test_Run_Vitest_2025-11-29.md`, including a fourth run where 20 test files and 50 tests (validation, engine, module, recommendation, and helper suites) all passed under an unrestricted environment.
- Added `docs/Integrity_Tests.md` to log integrity checks (TypeScript build failures, Vitest runs) with timestamps, detailed error capture, recommendations, and an explicit record of whether any fixes were applied in each run.
- Added `docs/process/DiagX_master_seed_V3.md` (DiagX master seed v3 scaffold).
- Added `docs/process/DiagX_engineer_seed_V1.md` (engineer-facing seed).
- Added `docs/process/DiagX_Safety_Manual_Outline.md` (safety manual section outline only).
- Added `docs/process/Local_Editor_Guardrails.md` (local editor / VS Code guardrails).
- Updated shared types in `src/shared/wshp.types.ts` to introduce `Recommendation` and `EngineResult` contracts.
- Updated airside, refrigeration, compressor, and reversing-valve modules to compile against shared types.
- Added `commander` dependency and fixed CLI build.

### 2025-11-29 Patch — Reciprocating compressor recommendations

- Fixed recommendation-gap for reciprocating compressors: when `compressionStatus === 'critical'` or `currentStatus === 'critical'` the engine now produces explicit critical safety recommendations. The recip recommendation generator was made flags-driven (no physics re-checks in the helper) and tests were added to lock this behavior. (see `test/compressor.recip.recommendations.test.ts`)

## 2025-11-29 Integrity sweep & final engine normalization

- Performed repo-wide integrity scan for single-source-of-truth on shared contracts. Confirmed `DiagnosticStatus`, `Recommendation` and `EngineResult` are defined only in `src/shared/wshp.types.ts`.
- Removed presentation-level strings from engine analysis helpers and engine return objects across modules, enforcing the EngineResult<V,F> contract (engines now return structured `values` and `flags` only):
	- `src/modules/airside/airside.engine.ts` — cleaned analysis helpers and moved message generation to module layer.
	- `src/modules/refrigeration/refrigeration.engine.ts` — removed message fields from analysis helpers and engine returns; engines produce structured flags and values.
	- `src/modules/compressor/recip.engine.ts` — removed message payloads from analysis helpers; engine returns now follow EngineResult<V,F>.
	- `src/modules/compressor/scroll.engine.ts` — removed message payloads and added `compressionStatus` flag; updated recommendation helper to use structured facts rather than textual messages.
	- `src/modules/reversingValve/reversing.engine.ts` — removed message strings and fixed structural issues; engines now produce `values` + `flags` and keep flattened fields for backward compatibility; module layer produces human-facing strings.
- Updated recommendation helpers and module logic to generate human-facing messages and presentation-level summaries in the module/UI layer (no physics or diagnosis logic changed, only presentation extraction).
- Fixed a few TypeScript type/import issues and duplicate-field errors surfaced during the refactor.
- Verified TypeScript build and Vitest test run: 20 test files, 50 tests — all passing after these changes.
