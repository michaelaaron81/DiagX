# DiagX Engines Inventory

This file is the canonical list of engine entry points targeted for Phase 2 normalization and review.

Engines:
- Airside
  - `src/modules/airside/airside.engine.ts`
- Refrigeration
  - `src/modules/refrigeration/refrigeration.engine.ts`
- Compressor – Reciprocating
  - `src/modules/compressor/recip.engine.ts`
  - Notes: critical compression and critical current flags now each produce dedicated safety recommendations via the engine's recommendation helper.
- Compressor – Scroll
  - `src/modules/compressor/scroll.engine.ts`
- Reversing Valve
  - `src/modules/reversingValve/reversing.engine.ts`
