```markdown
# Diagx-Omen – Repository File Tree

Repository: https://github.com/michaelaaron81/Diagx-Omen  
Default branch: `main`

This document shows the project structure with short descriptions and live GitHub links. It is focused on all files that matter for diagnostics, engines, modules, orchestration, and tests.

---

## High-Level Structure

```text
Diagx-Omen/
├─ .eslintrc.cjs
├─ .git/
├─ .prettierrc
├─ .vscode/
├─ dist/
├─ docs/
├─ Engines to be extracted/
├─ node_modules/
├─ scripts/
├─ src/
│  ├─ cli/
│  ├─ modules/
│  ├─ shared/
│  └─ wshp/
├─ test/
│  ├─ fixtures/
│  └─ *.test.ts
├─ package.json
├─ package-lock.json
├─ README.md
├─ Roadmap.docx
└─ tsconfig.json
```

---

## Root Files

- `README.md` – project overview and usage notes  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/README.md

- `Roadmap.docx` – roadmap / planning document (binary)  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/Roadmap.docx

- `package.json` – Node/TypeScript project manifest and scripts  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/package.json

- `package-lock.json` – exact dependency lockfile  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/package-lock.json

- `tsconfig.json` – TypeScript compiler configuration  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/tsconfig.json

- `.eslintrc.cjs` – ESLint configuration  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/.eslintrc.cjs

- `.prettierrc` – Prettier formatting configuration  
	https://github.com/michaelaaron81/Diagx-Omen/blob/main/.prettierrc

- `.vscode/` – workspace/editor settings for VS Code  
	https://github.com/michaelaaron81/Diagx-Omen/tree/main/.vscode

- `dist/` – compiled output (when `tsc` build is run)  
	https://github.com/michaelaaron81/Diagx-Omen/tree/main/dist

- `.git/` – git metadata (not browsed in GitHub UI; internal to git)

---

## `docs/` (internal/process)

This folder contains the internal guidance and process artifacts (seed docs, file tree, and instructions) grouped under `docs/process/`.

---

The canonical file tree is maintained at the project root: `FILE_TREE.md`.
----

The canonical file tree is maintained at the project root: `FILE_TREE.md`.
```