# Combined Profile Stress Test — Audit (2025-11-29)

This is a human-friendly audit of the combined-profile stress test executed on 2025-11-29. It records exactly what I ran, how I ran it, what the engines produced, cross-module observations (correlations), and the suggested follow-up actions to address gaps.

Summary (TL;DR)
- Purpose: stress-test multiple engine modules together (airside, refrigeration, reciprocating & scroll compressors, reversing valve) using a single WSHP *profile* and a set of fabricated, problematic measurements that emulate an airside restriction cascading into refrigeration and electrical symptoms.
- Outcome: Engines detected local issues correctly (airside critical, refrigeration alerts, compressor/valve flags). Some gaps were identified where critical flags did not produce matching safety recommendations (notably the reciprocating compressor's high current scenario).
- Artifacts produced: `test/combined.profile.stress.test.ts`, `scripts/run-combined-profile.ts`, `docs/gap-scans/Recommendation_Gaps_2025-11-29.md`, and `docs/recommendations/Recommendation_Suggestions_2025-11-29.md`.

1) Why we ran this test
- Goal: simulate a realistic systemic fault where an external (airside) problem (e.g., severe airflow restriction / iced coil) leads to secondary effects in the refrigeration side and compressors. The test confirms that:
  - Engines identify their own domain-level problems (OK)
  - Recommendations capture safety-critical actions (partially OK)
  - Inter-domain correlations are visible and can be surfaced (improvements needed)

2) How the test was executed (process)
- I created a small script and a unit test harness that exercise all engines in one profile run without making modifications to core engine code (tools in /scripts and /test). Important steps:
  1. Constructed a WSHP profile representing a 5-ton unit (profile includes airside, refrigeration, compressor, reversing valve sections).
  2. Fabricated linked measurements across domains to model an airside restriction scenario: very high ΔT (supply air 30°F / return 78°F) and very low CFM (600 for a 5-ton → ~120 CFM/ton), combined with refrigeration measurements consistent with abnormal performance (low suction pressure, mismatched superheat/subcooling) and compressor current numbers.
  3. Ran the engines in sequence: airside -> refrigeration -> recip & scroll compressors -> reversing valve and collected flags & recommendations.
  4. Recorded results, then ran automated “gap detection” tests that scan recommendation text for keywords tied to flags to find cases where a flag did not lead to an appropriate recommendation.

3) Exact test inputs used (representative)
- Profile: 5-ton unit, designCFM.cooling = 2400 CFM, refrigeration R-410A, compressor = scroll with RLA 10, reversing valve solenoid 24V.
- Airside measurements: mode=cool, returnAirTemp=78°F, supplyAirTemp=30°F (ΔT=48°F), measuredCFM=600, externalStatic=0.85 in.W.C.
- Refrigeration measurements: suctionPressure=70 PSIG, dischargePressure=360 PSIG, suctionTemp=60°F, liquidTemp=95°F, enteringWaterTemp=80°F, leavingWaterTemp=88°F.
- Compressor measurements: recip: current=30A (with RLA 50 set on profile), scroll: runningCurrent=12A (RLA=10)
- Reversing valve: solenoid=24V, ports pattern leaning reversed/mismatched

4) Results — per module (engine outputs summarized)
- Airside
  - Flags: deltaTStatus = critical, airflowStatus = critical, staticPressureStatus = critical
  - Recommendation: CRITICAL — "Check for Frozen Coil or Severe Restriction" (turn off cooling, leave fan on, inspect filter/coil)

- Refrigeration
  - Flags: superheat = alert, subcooling = alert, compressionRatio = warning
  - Recommendation: HIGH — "Refrigerant Leak — Undercharged System" (perform leak detection & repair before charging)

- Reciprocating compressor
  - Flags: compressionStatus = ok, currentStatus = critical
  - Recommendation: None — (gap: critical current should trigger a safety recommendation such as shutdown and electrical/mechanical checks)

- Scroll compressor
  - Flags: currentStatus = alert, compressionStatus = ok
  - Recommendation: HIGH — "Inspect compressor motor current" (electrical checks and inspection)

- Reversing valve
  - Flags: patternMatch = reversed, solenoidStatus = ok
  - Recommendation: HIGH — "Reversing Valve Not Switching Modes" (check solenoid, tap valve, consider replacement)

5) Cross-domain observations (correlation & cause/effect)
- The airside engine correctly found a severe airflow restriction and recommended taking the cooling offline — this is precisely the correct safety-first outcome.
- The refrigeration engine showed superheat/subcooling abnormalities consistent with a system now operating outside its designed heat transfer envelope. This can easily be caused by airside restriction (reduced heat transfer at the evaporator), so the refrigeration recommendation (leak check) is plausible — but it would be stronger if the system explicitly considered the airside condition in its diagnostic narrative and recommended checks that account for airside-caused measurement distortions.
- Reversing valve showed a reversed pattern — possibly unrelated to the airside problem, but important to show concurrently.
- The recip compressor produced a critical current flag but no recommendation — this is a clear safety gap: critical current should yield immediate action advice (shutdown, electrical isolation, and qualified technician inspection). The scroll compressor DID return a current-related recommendation — good.

6) Gaps found (concrete)
- Missing critical action for reciprocating compressor when currentStatus === 'critical' (should recommend shutdown and electrical/mechanical checks).
- Airside recommendations are accurate, but they lack structured diagnostic steps to quantify/confirm root cause (measure airflow/ESP, verify filter ΔP, inspect blower & ductwork, controlled defrost steps) — these additions are in `docs/recommendations/Recommendation_Suggestions_2025-11-29.md`.
- The system does not yet provide cross-domain advisories (e.g., airside critical + refrigeration abnormal ⇒ 'do not restart compressor until defrost / verify refrigerant/charge') — the orchestrator can be improved to detect and surface these correlations.

7) Suggested next actions (recommended by priority)
- Immediate (safety) fixes
  1) Add a `critical` recommendation for reciprocating compressors when current is critical: instruct immediate shutdown, electrical isolation, and qualified technician inspection.
  2) For refrigeration, add a safety stop recommendation when superheat is extremely low (risk of liquid slugging).

- Medium-term (diagnostic quality)
  3) Expand airside recommendations to include step-by-step diagnostic actions: measure airflow & ESP, replace/clean filter, inspect blower & ductwork, controlled defrost steps.
  4) Add tests that assert the newly introduced recommendation IDs are present when flags trigger — prevents regressions.

- Long-term (cross-domain orchestration)
  5) Extend the orchestrator (`runWshpDiagx`) to aggregate domain results and run correlation rules that add cross-domain advisories when certain co-occurring flags appear (e.g., airside critical + refrigeration abnormal ⇒ 'do not restart compressor until defrost / verify refrigerant/charge').

8) Files produced / where to look
- Test & script artifacts (no engine code changed):
  - `test/combined.profile.stress.test.ts` — a unit test that runs the combined scenario and prints engine outputs
  - `scripts/run-combined-profile.ts` — one-off script to execute the same scenario locally
- Documentation & scans (committed):
  - `docs/gap-scans/Recommendation_Gaps_2025-11-29.md` — automated scan results showing gaps
  - `docs/recommendations/Recommendation_Suggestions_2025-11-29.md` — human-readable, suggested recommendations and test cases

9) Closing notes and safety emphasis
- Engines behaved correctly within their domain responsibilities and detected important conditions. The primary risk found in this combined run is the missing safety recommendation for the reciprocating compressor when current becomes critical — that is a safety priority.
- Cross-domain rules will improve the accuracy of human-facing advice (for example, the system should avoid recommending a compressor restart after a frozen coil without explicit steps verifying defrost and refrigerant conditions).

If you want, I can immediately implement the top safety fixes (recip critical-current recommendation and refrigeration superheat safety-stop), add tests and push a PR — would you like me to proceed with those now? 

End of audit — 2025-11-29

Audit created by automation (scripts/run-combined-profile.ts & tests) and saved to docs.
