# Docs — Inventory

This folder is the canonical home for inventory documents, engine specs, catalogs, and the internal file tree.

Canonical contents:
- `DiagX_Engines_Inventory.md`
- `Engines_Core_Spec.md`
- `FILE_TREE.md`
