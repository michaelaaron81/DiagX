# Docs — Plans & Implementation

This folder holds implementation plans, repair plans, and other 'to-do' documents that describe how to fix or evolve the codebase.

Canonical contents:
- `Plan_to_fix_existing_integrity_issues.md`
