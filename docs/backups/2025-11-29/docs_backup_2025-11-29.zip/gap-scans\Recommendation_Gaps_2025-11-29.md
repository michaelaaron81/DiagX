# Recommendation Gaps Scan — 2025-11-29

Scanned at: 2025-11-29T17:49:41.870Z

{
  "scannedAt": "2025-11-29T17:49:41.870Z",
  "findings": [
    {
      "engine": "airside",
      "scenario": "frozen_coil_like",
      "flags": {
        "mode": "cooling",
        "deltaTStatus": "critical",
        "deltaTSource": "industry",
        "cfmSource": "nameplate_calculated",
        "airflowStatus": "critical",
        "staticPressureStatus": "critical",
        "disclaimers": [
          "Always verify expected coil and fan curves with the equipment Installation, Operation & Maintenance (IOM) manual. You can pass manufacturer ranges via profile.airside.manufacturerExpectedDeltaT and profile.airside.manufacturerCFMPerTon if available (do not commit OEM data into the repository).",
          "Manufacturer data for coil performance not found in profile — relying on industry defaults. Verify with equipment documentation."
        ]
      },
      "recCount": 1,
      "gaps": [
        "No recommendation relating to airflow (measure/inspect/repair)",
        "No recommendation relating to static pressure / ductwork"
      ]
    },
    {
      "engine": "airside",
      "scenario": "very_high_airflow",
      "flags": {
        "mode": "cooling",
        "deltaTStatus": "warning",
        "deltaTSource": "industry",
        "cfmSource": "nameplate_calculated",
        "airflowStatus": "alert",
        "staticPressureStatus": "ok",
        "disclaimers": [
          "Always verify expected coil and fan curves with the equipment Installation, Operation & Maintenance (IOM) manual. You can pass manufacturer ranges via profile.airside.manufacturerExpectedDeltaT and profile.airside.manufacturerCFMPerTon if available (do not commit OEM data into the repository).",
          "Manufacturer data for coil performance not found in profile — relying on industry defaults. Verify with equipment documentation."
        ]
      },
      "recCount": 1,
      "gaps": [
        "No recommendation relating to delta-T / frozen coil / restriction"
      ]
    },
    {
      "engine": "airside",
      "scenario": "low_delta_but_low_cfm",
      "flags": {
        "mode": "cooling",
        "deltaTStatus": "warning",
        "deltaTSource": "industry",
        "cfmSource": "nameplate_calculated",
        "airflowStatus": "critical",
        "staticPressureStatus": "ok",
        "disclaimers": [
          "Always verify expected coil and fan curves with the equipment Installation, Operation & Maintenance (IOM) manual. You can pass manufacturer ranges via profile.airside.manufacturerExpectedDeltaT and profile.airside.manufacturerCFMPerTon if available (do not commit OEM data into the repository).",
          "Manufacturer data for coil performance not found in profile — relying on industry defaults. Verify with equipment documentation."
        ]
      },
      "recCount": 1,
      "gaps": [
        "No recommendation relating to delta-T / frozen coil / restriction"
      ]
    },
    {
      "engine": "refrigeration",
      "scenario": "very_low_superheat",
      "flags": {
        "superheatStatus": "ok",
        "subcoolingStatus": "alert",
        "compressionRatioStatus": "ok",
        "waterTransferStatus": "alert",
        "disclaimers": [
          "PT calculations use repository PT charts (generic ASHRAE/manufacturer references). Always verify with equipment IOM manuals; to provide a custom PT table you may set profile.refrigeration.ptOverride and the refrigerant value to \"OTHER\" at runtime (do NOT commit OEM data into the repository)."
        ]
      },
      "recCount": 1,
      "gaps": [
        "No recommendation addressing subcooling/overcharge"
      ]
    },
    {
      "engine": "refrigeration",
      "scenario": "overcharge_like",
      "flags": {
        "superheatStatus": "alert",
        "subcoolingStatus": "alert",
        "compressionRatioStatus": "ok",
        "waterTransferStatus": "alert",
        "disclaimers": [
          "PT calculations use repository PT charts (generic ASHRAE/manufacturer references). Always verify with equipment IOM manuals; to provide a custom PT table you may set profile.refrigeration.ptOverride and the refrigerant value to \"OTHER\" at runtime (do NOT commit OEM data into the repository)."
        ]
      },
      "recCount": 2,
      "gaps": [
        "No recommendation addressing superheat / liquid slugging / safety stop"
      ]
    },
    {
      "engine": "refrigeration",
      "scenario": "high_water_dt",
      "flags": {
        "superheatStatus": "alert",
        "subcoolingStatus": "alert",
        "compressionRatioStatus": "ok",
        "waterTransferStatus": "alert",
        "disclaimers": [
          "PT calculations use repository PT charts (generic ASHRAE/manufacturer references). Always verify with equipment IOM manuals; to provide a custom PT table you may set profile.refrigeration.ptOverride and the refrigerant value to \"OTHER\" at runtime (do NOT commit OEM data into the repository)."
        ]
      },
      "recCount": 2,
      "gaps": []
    },
    {
      "engine": "compressor_recip",
      "scenario": "low_compression_ratio",
      "flags": {
        "compressionStatus": "critical",
        "currentStatus": "ok",
        "recipHealth": {},
        "disclaimers": [
          "Custom refrigerant detected — verify limits and consult manufacturer IOM for reciprocating-specific guidance (reciprocating compressors are less tolerant of liquid refrigerant)."
        ]
      },
      "recCount": 1,
      "gaps": []
    },
    {
      "engine": "compressor_recip",
      "scenario": "very_high_current",
      "flags": {
        "compressionStatus": "ok",
        "currentStatus": "critical",
        "recipHealth": {},
        "disclaimers": [
          "Custom refrigerant detected — verify limits and consult manufacturer IOM for reciprocating-specific guidance (reciprocating compressors are less tolerant of liquid refrigerant)."
        ]
      },
      "recCount": 1,
      "gaps": []
    },
    {
      "engine": "compressor_scroll",
      "scenario": "bad_compression",
      "flags": {
        "currentStatus": "ok",
        "compressionStatus": "alert",
        "disclaimers": []
      },
      "recCount": 1,
      "gaps": []
    },
    {
      "engine": "compressor_scroll",
      "scenario": "high_current",
      "flags": {
        "currentStatus": "critical",
        "compressionStatus": "ok",
        "disclaimers": []
      },
      "recCount": 1,
      "gaps": []
    },
    {
      "engine": "reversing_valve",
      "scenario": "stuck_valve",
      "flags": {
        "patternMatch": "stuck",
        "solenoidStatus": "ok"
      },
      "recCount": 1,
      "gaps": []
    },
    {
      "engine": "reversing_valve",
      "scenario": "reversed_pattern",
      "flags": {
        "patternMatch": "reversed",
        "solenoidStatus": "ok"
      },
      "recCount": 1,
      "gaps": []
    }
  ]
}