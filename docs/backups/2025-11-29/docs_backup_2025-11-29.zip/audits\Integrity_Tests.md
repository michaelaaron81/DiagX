# Integrity Tests Log

## [2025-11-29T??:??] TypeScript Build Integrity Check (`npm run build`)

- **Scope:** Full TypeScript project build using `tsc -p tsconfig.json`.
- **Result:** **FAILED** – TypeScript compiler reported structural/type mismatches in several engine files.
- **Compiler errors observed (verbatim):**
	- `src/modules/airside/airside.engine.ts(232,5): error TS2353: Object literal may only specify known properties, and 'deltaTMessage' does not exist in type 'AirsideEngineFlags'.`
	- `src/modules/airside/airside.engine.ts(256,5): error TS2353: Object literal may only specify known properties, and 'deltaTMessage' does not exist in type 'AirsideEngineResult'.`
	- `src/modules/airside/airside.engine.ts(256,26): error TS2339: Property 'deltaTMessage' does not exist on type 'AirsideEngineFlags'.`
	- `src/modules/airside/airside.engine.ts(265,27): error TS2339: Property 'airflowMessage' does not exist on type 'AirsideEngineFlags'.`
	- `src/modules/airside/airside.engine.ts(267,34): error TS2339: Property 'staticPressureMessage' does not exist on type 'AirsideEngineFlags'.`
	- `src/modules/airside/airside.engine.ts(271,35): error TS2339: Property 'humidityRemovalMessage' does not exist on type 'AirsideEngineFlags'.`
	- `src/modules/airside/airside.engine.ts(273,27): error TS2339: Property 'overallFinding' does not exist on type 'AirsideEngineFlags'.`
	- `src/modules/airside/airside.engine.ts(274,24): error TS2339: Property 'likelyIssue' does not exist on type 'AirsideEngineFlags'.`
	- `src/modules/compressor/recip.engine.ts(213,10): error TS2352: Conversion of type '{ status: DiagnosticStatus; compressorId: string | undefined; compressionRatio: number; compressionStatus: DiagnosticStatus; current: number | undefined; ... 5 more ...; recommendations: Recommendation[]; }' to type 'ReciprocatingCompressorResult' may be a mistake because neither type sufficiently overlaps with the other. If this was intentional, convert the expression to 'unknown' first. Type '{ status: DiagnosticStatus; compressorId: string | undefined; compressionRatio: number; compressionStatus: DiagnosticStatus; current: number | undefined; ... 5 more ...; recommendations: Recommendation[]; }' is missing the following properties from type 'ReciprocatingCompressorResult': values, flags.`
	- `src/modules/compressor/scroll.engine.ts(124,3): error TS2739: Type '{ status: DiagnosticStatus; compressorType: "scroll"; suctionPressure: number; dischargePressure: number; compressionRatio: number; dischargeSuperheat: number | undefined; currentDraw: number | undefined; currentStatus: DiagnosticStatus; disclaimers: string[]; recommendations: Recommendation[]; }' is missing the following properties from type 'ScrollCompressorResult': values, flags.`
	- `src/modules/refrigeration/refrigeration.engine.ts(279,3): error TS2739: Type '{ status: DiagnosticStatus; mode: "cooling" | "heating"; suctionPressure: number; dischargePressure: number; suctionSatTemp: number; dischargeSatTemp: number; superheat: number; ... 9 more ...; disclaimers: string[]; }' is missing the following properties from type 'RefrigerationEngineResult': values, flags.`
	- `src/modules/reversingValve/reversing.engine.ts(139,3): error TS2739: Type '{ status: DiagnosticStatus; requestedMode: "cooling" | "heating"; portTemps: { dischargeInlet: number; suctionReturn: number; indoorCoilLine: number; outdoorCoilLine: number; }; ... 6 more ...; recommendations: Recommendation[]; }' is missing the following properties from type 'ReversingValveDiagnosis': values, flags.`
	- `src/modules/reversingValve/reversing.module.ts(81,21): error TS2304: Cannot find name 'criticalRec'.`
	- `src/modules/reversingValve/reversing.module.ts(81,36): error TS2304: Cannot find name 'criticalRec'.`
	- `src/modules/reversingValve/reversing.module.ts(81,57): error TS2304: Cannot find name 'criticalRec'.`
- **Recommendations (for DiagX Architect / Type Owner):**
	- Review and reconcile the return types and flag/value shapes for:
		- `AirsideEngineFlags` / `AirsideEngineResult` vs. the object literals built in `src/modules/airside/airside.engine.ts`.
		- `ReciprocatingCompressorResult` vs. the returned object in `src/modules/compressor/recip.engine.ts`.
		- `ScrollCompressorResult` vs. the returned object in `src/modules/compressor/scroll.engine.ts`.
		- `RefrigerationEngineResult` vs. the returned object in `src/modules/refrigeration/refrigeration.engine.ts`.
		- `ReversingValveDiagnosis` vs. the returned object in `src/modules/reversingValve/reversing.engine.ts`.
	- Decide, at the architectural level, whether the authoritative contracts are the shared `EngineResult`-style types or the existing engine return structures, and then adjust types and/or mapping code accordingly so TypeScript compiles without changing diagnostic physics or recommendations.
	- Define or correctly import the `criticalRec` symbol used in `src/modules/reversingValve/reversing.module.ts` so that the recommendation wiring there matches the intended recommendation helper API.
- **Fixes applied in this run:**
	- **None.** Errors were recorded only; no changes were made to engine logic, types, or modules as part of this integrity test.

## [2025-11-29T10:18:54] Vitest Extended Suite Integrity Check (`npm test -- --run`)

- **Scope:** Full Vitest run with validation, engine, module, recommendation, and helper suites (20 files, 50 tests).
- **Result:** **PASSED** – all 20 test files and 50 tests completed successfully.
- **Notable observations:**
	- Vitest executed with `vitest.config.ts` present and reported:
		- `Test Files 20 passed (20)`
		- `Tests 50 passed (50)`
		- Start at `10:18:54`, duration `1.17s` (with internal timing for transform/setup/collect/tests/environment).
	- Suites covered:
		- Airside: validation, recommendations, engine full tests, module integration.
		- Refrigeration: engine full tests, demo WSHP wrapper, PT override behavior, PT table validation, recommendations.
		- Compressors: reciprocating and scroll engines, modules, and recommendation helpers.
		- Reversing valve: engine, module, and recommendation helpers.
		- Local overrides CLI helpers.
- **Recommendations:**
	- Keep the Vitest suite as a primary regression gate before any changes to diagnostic logic, thresholds, or recommendations.
	- Monitor the Vite CJS Node API deprecation warning surfaced during the run and, when appropriate, migrate tooling per Vite’s official guidance, without altering diagnostic behavior.
	- Periodically re-run this extended suite after any structural changes to `EngineResult`/module contracts to ensure scenarios documented in `docs/Test_Run_Vitest_2025-11-29.md` remain green.
- **Fixes applied in this run:**
	- **None.** This integrity test was observational only; no code or configuration changes were introduced after the successful run.

